from django.urls import path
from . import views

urlpatterns = [
    path('remplirForm/<str:id>', views.remplirForm,name='remplirForm'),
    path('modifierReponse/<str:id>', views.modifierReponse,name='modifierReponse'),
    path('reponse/<str:id>', views.modifierReponse,name='reponse')

]