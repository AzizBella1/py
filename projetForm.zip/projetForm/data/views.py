import json

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect

from data.models import Data
from form.models import Form


# Create your views here.


@login_required(login_url='login')
def remplirForm(request,id):
    form = Form.objects.get(id=id)
    jsonForm=json.loads(form.json)
    liste=[]
    context = {'form': form}
    if request.method == 'POST':
        cnt=0
        for x in request.POST:
            if cnt>0:
                liste.append(request.POST[x])
            else:
                cnt=cnt+1
        j=0
        for x in jsonForm:
            if x['type'] != 'header':
                x['value']=liste[j]
                j=j+1

        jsonForm = json.dumps(jsonForm)
        jsonForm = jsonForm.replace("'","\"")
        data = Data(user=5, form=id, data=jsonForm)
        data.save()
        return redirect('user')
        #context={'form':form,'post':liste}
    return render(request, 'data/remplir_form.html',context)


@login_required(login_url='login')
def modifierReponse(request,id):
    data = Data.objects.get(form=id)
    form = Form.objects.get(id=id)
    jsonForm = json.loads(form.json)

    listePost = []
    context = {'data': data,'form': form}
    if request.method == 'POST':
        cnt = 0
        for x in request.POST:
            if cnt>0:
                listePost.append(request.POST[x])
            else:
                cnt=cnt+1

        j = 0
        for x in jsonForm:
            if x['type'] != 'header':
                if x['type'] == 'checkbox-group':
                    x['values'][0]["selected"] = not (x['values'][0]["selected"])
                    j = j + 1
                else:
                    x['value'] = listePost[j]
                    j = j + 1

        jsonForm = json.dumps(jsonForm)
        jsonForm = jsonForm.replace("'","\"")
        data.data = jsonForm



        data.save()
        return redirect('user')
        #context={'form':form,'post':liste}
    return render(request, 'data/modifier_reponse.html',context)
