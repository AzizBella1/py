from django.db import models

# Create your models here.
class Data(models.Model):
    user = models.IntegerField()
    form = models.IntegerField()
    data = models.TextField(max_length=600, null=True)
    date_creation = models.DateTimeField(auto_now_add=True, null=True)

