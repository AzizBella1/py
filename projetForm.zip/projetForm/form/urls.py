from . import views
from django.urls import path, include

urlpatterns = [
    path('', views.home,name="home"),
    path('home/', views.home, name="home"),
    path('forms/', views.list_form, name="forms"),
    path('forms/apercuForm/<str:id>', views.apercuForm, name="apercuForm"),
    path('listUser/', views.list_user, name="listUser"),
    path('forms/creerForm', views.creerForm, name="creerForm"),
    path('forms/modifierForm/<str:id>', views.modifierForm, name="modifierForm"),
    path('forms/validerForm/<str:id>', views.validerForm, name="validerForm"),
    path('forms/supprimerForm/<str:id>', views.supprimerForm, name="supprimerForm"),
    path('forms/detailForm/<str:id>', views.detailForm, name="detailForm"),
    path('forms/detailUser', views.detailUser, name="detailUser"),
    path('etatForm/<str:id>', views.etatForm, name="etatForm"),
]
