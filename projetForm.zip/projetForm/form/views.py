from django.contrib.auth.decorators import login_required
from django.shortcuts import render,redirect

from data.models import Data
from .models import Form
from django.contrib.auth import get_user_model
from django.http import HttpResponse

# Create your views here.
@login_required(login_url='login')
def home(request):
    forms = Form.objects.all()
    context = {'forms': forms}
    return render(request,'form/acceuil.html',context)
    #return HttpResponse('helloooooo')

@login_required(login_url='login')
def list_form(request):
    forms = Form.objects.all()
    context = {'forms': forms}
    return render(request, 'form/list_form.html',context)

@login_required(login_url='login')
def list_user(request):
    User = get_user_model()
    users = User.objects.raw("Select * FROM auth_user WHERE is_staff=0")
    context = {'users':users}
    return render(request, 'form/list_user.html',context)

@login_required(login_url='login')
def creerForm(request):
    if request.method=='POST':
        form = Form(nom=request.POST['name'],admin=request.POST['admin'],json=request.POST['tex'])
        form.save()
        return redirect('home')


    return render(request, 'form/creer_form.html')

@login_required(login_url='login')
def modifierForm(request,id):
    form = Form.objects.get(id=id)

    if request.method == 'POST':
        form.json = request.POST['tex']
        form.save()
        return redirect('/home')
    context={'form':form}
    return render(request, 'form/modifier_form.html',context)

@login_required(login_url='login')
def validerForm(request,id):
    form = Form.objects.get(id=id)

    if request.method == 'POST':
        form.is_valid = not form.is_valid
        form.save()
        return redirect('/home')

    return render(request, 'form/valider_form.html')

@login_required(login_url='login')
def supprimerForm(request,id):
    form = Form.objects.get(id=id)
    if request.method == 'POST':
        form.delete()
        return redirect('/home')

    return render(request,'form/supprimer_form.html')

@login_required(login_url='login')
def etatForm(request,id):
    form = Form.objects.get(id=id)
    if request.method == 'POST':
        form.is_archifed = not form.is_archifed
        form.save()
        return redirect('/home')
    return render(request, 'form/etat_form.html')

@login_required(login_url='login')
def detailForm(request,id):
    form = Form.objects.get(id=id)
    data = Data.objects.raw("SELECT * FROM data_data WHERE form="+id)
    nb_reponse = 0
    for x in data:
        nb_reponse = nb_reponse+1

    context={'form':form,'nb_reponse':nb_reponse,'data':data}
    return render(request, 'form/info_form.html',context)

@login_required(login_url='login')
def detailUser(request):
    return render(request, 'form/info_user.html')


@login_required(login_url='login')
def apercuForm(request,id):
    form = Form.objects.get(id=id)
    context={'form':form}
    return render(request, 'form/apercu.html',context)


