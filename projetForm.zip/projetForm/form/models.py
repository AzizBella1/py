from django.db import models

# Create your models here.
class Form(models.Model):
    nom = models.CharField(max_length=70,null=True)
    admin=models.IntegerField()
    json = models.TextField(max_length=600, null=True)
    is_valid = models.BooleanField(default=0)
    is_archifed = models.BooleanField(default=0)
    date_creation = models.DateTimeField(auto_now_add=True, null=True)

    def __str__(self):
        return self.nom
