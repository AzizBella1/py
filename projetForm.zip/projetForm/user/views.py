from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm
from .form import CreerUser
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from form.models import Form
from  data.models import Data
from django.contrib.auth import get_user_model



# Create your views here.
def inscriptionPage(request):
    form = CreerUser()
    if request.method=='POST':
        form=CreerUser(request.POST)
        if form.is_valid():
            form.save()
            user=form.cleaned_data.get('username')
            messages.success(request,user+' Creer avec succes')
            return redirect('login')
    context={'form':form}
    return render(request,'user/inscription.html',context)

def loginPage(request):


    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            if user.is_staff == 0:
                return redirect('home/user')
            else:
                return redirect('home')


        else:
            messages.info(request, 'username ou password incorrect')

    return render(request,'user/login.html')

def logoutUser(request):
    logout(request)
    return redirect('login')


def formDisponible(request):
    formRemplir = Data.objects.raw("SELECT * FROM data_data WHERE user="+str(request.user.id))
    formList = []
    for x in formRemplir:
        formList.append(x.form)
    forms = Form.objects.raw("Select * FROM form_form WHERE is_valid=1 and is_archifed=0")
    data = Data.objects.raw("SELECT * FROM data_data")
    User = get_user_model()
    users = User.objects.raw("Select * FROM auth_user WHERE is_staff=1")
    context = {'formDespo': forms,'admins':users,'data':data,'formRemplir':formList}
    return render(request,'form/acceuil.html',context)

def mesForm(request):
    forms = Form.objects.raw("Select * FROM form_form ")
    User = get_user_model()
    users = User.objects.raw("Select * FROM auth_user WHERE is_staff=1")
    context = {'formsUser': forms,'admins':users}
    return render(request,'user/forms.html',context)

def formRemplir(request):
    formsRemplit = Data.objects.raw("Select * FROM data_data WHERE user="+str(request.user.id))
    forms = Form.objects.raw("Select * FROM form_form ")
    context = {'formsRemplit': formsRemplit,'forms': forms}
    return render(request,'user/forms.html',context)

