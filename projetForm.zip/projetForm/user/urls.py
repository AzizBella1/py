from django.urls import path, include
from . import views

urlpatterns = [
    path('inscription', views.inscriptionPage,name='inscription'),
    path('login', views.loginPage,name='login'),
    path('logout', views.logoutUser, name='logout'),
    path('listForms/', views.formRemplir,name='listForms'),
    path('home/user/', views.formDisponible, name="user"),
    path('remplirForm/', include('data.urls')),
    path('modifierReponse/', include('data.urls')),
]