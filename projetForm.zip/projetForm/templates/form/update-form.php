<!DOCTYPE html>
<html>
<head>
    <title>test</title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <style>
      #setData{
        margin-top: 10px;
        margin-bottom: 10px;
        margin-left: 400px;
      }

      body {
        background: lightgrey;
        font-family: sans-serif;
      }

      #view{
        width: 600px;
        height: 200px;
        background-color: white;
        position: absolute;
        left: 300px;
        top: 100px;
        z-index: 1;
      }

      .form-rendered #build-wrap {
        display: none;
      }

      .render-wrap {
        display: none;
        background-color: wheat;
      }

      .form-rendered .render-wrap {
        display: block;
      }

      #edit-form {
        display: none;
        float: right;
      }

      #valid{
        width: 200px;
        height: 50px;
        margin-left: 350px;
      }

      .form-rendered #edit-form {
        display: block;
      }
    </style>
</head>
<body>
  <div id="view">
    <input class="btn-danger" type="button" id="close" value="X">
    <div class="render-wrap">

    </div>
    
  </div>
    <form id="form" action="">
      <textarea name="tex" hidden id="tex" cols="30" rows="10"><?php echo $_GET['tex'];?></textarea>
      
      <div id="fb-editor"></div>
      <div id="fb-edito"></div>
     
     
      <input id="valid" type="submit" class="btn-success" name="save" value="Valid">
     
      
      <input type="hidden" name="id" value="<?php echo $_GET['id'];?>">
      
    </form>
    
  <script src="jquery-3.6.0.min.js"></script>
  <script src="jquery-ui.js"></script>
  <script src="form-builder.min.js"></script>
  <script src="form-render.min.js"></script>
  <script>
      document.getElementById('view').style.visibility="hidden";
      document.getElementById('valid').style.visibility="hidden";
     
      
      jQuery(function ($) {
        //document.getElementById("fb-edito").style.visibility="hidden";
        //var formData = document.getElementById('tex').value;
        var options = {
              onSave: function (evt, formData) {
                console.log("formbuilder saved");
                toggleEdit(false);
                
                $(".render-wrap").formRender({ formData });
                document.getElementById('tex').value = formData
                document.getElementById('valid').style.visibility="visible";
                document.getElementById('view').style.visibility="visible";
                document.getElementById('form').style.opacity=0.2
              },
              onClearAll: function(formData) {
                toggleEdit(true);
                document.getElementById('valid').style.visibility="hidden";
              }
            };
        var fbEditor = document.getElementById('fb-editor');
        var formBuilder = $(fbEditor).formBuilder(options);
        
        
        
        
        $(document).ready(function(){
          
          setInterval(function(){
            formBuilder.actions.setData(document.getElementById('tex').value);
          },3); 

        });
        
        

        document.getElementById('close').addEventListener('click', function() {
            document.getElementById('view').style.visibility="hidden";
            document.getElementById('form').style.opacity=1
            //alert(document.getElementById('tex').value)
        });


for(const x in obj){
    if(x.type != "header"){
        alert(x.type)
    }
}
        
        
        
          
      });
      function toggleEdit(editing) {
        document.body.classList.toggle("form-rendered", !editing);
      }
      
      
    

  </script>
</body>
<?php
  if(isset($_GET['save'])){
    $conn= new PDO("mysql:host=localhost;dbname=form-builder","root","root");
    $req = "UPDATE form SET json='".$_GET['tex']."' WHERE id=".$_GET['id'];
    $set = $conn->prepare($req);
    $set->execute();
    if ($set->rowCount()) {
      echo "<div id='alert'><div class='alert alert-success' >Bien modifier</div></div>";
      header("refresh: 1; url = http://localhost:8888/A--/index.php");
    }else{
      echo "<div id='alert'><div class='alert alert-danger' >Erreur de modification</div></div>";
    }
  }
  

?>
