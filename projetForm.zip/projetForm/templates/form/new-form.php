<!DOCTYPE html>
<html>
<head>
    <title>new-form</title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <style>
      body {
        background: lightgrey;
        font-family: sans-serif;
      }

      #view{
        width: 600px;
        height: 200px;
        background-color: white;
        position: absolute;
        left: 300px;
        top: 100px;
        z-index: 1;
      }


      .form-rendered #build-wrap {
        display: none;
      }

      .render-wrap {
        display: none;
        background-color: wheat;
      }

      .form-rendered .render-wrap {
        display: block;
      }

      #edit-form {
        display: none;
        float: right;
      }

      .form-rendered #edit-form {
        display: block;
      }


    </style>
</head>
<body>
  <div id="view">
    <input class="btn-danger" type="button" id="close" value="X">
    <div class="render-wrap"></div>
  </div>

  <form id="form" action="">
    
    <div id="fb-editor"></div>

    <div id="valid"> 
      <input type="text" name="name" placeholder="Form Name">
      <input type="submit" class="btn-success" id="save" name="save" value="Valid">
    </div>
    
    <textarea hidden name="tab" id="tab" cols="30" rows="10"></textarea>
    <textarea hidden name="tex" id="tex" cols="30" rows="10"></textarea>
  </form>
  <script src="jquery-3.6.0.min.js"></script>
  <script src="jquery-ui.js"></script>
  <script src="form-builder.min.js"></script>
  <script src="form-render.min.js"></script>
  <script>
    
      document.getElementById('view').style.visibility="hidden";
      jQuery(function ($) {
        
          var fbTemplate = document.getElementById("fb-editor");
          document.getElementById('valid').style.visibility="hidden";
          

          
          var options = {
              onSave: function (evt, formData) {
                console.log("formbuilder saved");
                toggleEdit(false);
                $(".render-wrap").formRender({ formData });
                document.getElementById('tex').value = formData
                document.getElementById('valid').style.visibility="visible";
                document.getElementById('view').style.visibility="visible";
                document.getElementById('form').style.opacity=0.2

                const obj = JSON.parse(formData);
                var tab = [];
                obj.forEach(element => {
                  if (element.type != 'header') {
                    tab.push(element.name);
                  }
                  
                  //alert(element.name)
                });
                document.getElementById('tab').value = tab;
                
                
              },
              onClearAll: function(formData) {
                document.getElementById('valid').style.visibility="hidden";
                toggleEdit(true);
              }
          };
          

          
          $(fbTemplate).formBuilder(options);
          // document.getElementById('save').addEventListener('mouseover', function() {
          //   alert(document.getElementById('tex').value)
          // });
          
          
      });
      function toggleEdit(editing) {
        document.body.classList.toggle("form-rendered", !editing);
      }

      document.getElementById('close').addEventListener('click', function() {
            document.getElementById('view').style.visibility="hidden";
            document.getElementById('form').style.opacity=1
            //alert(document.getElementById('tex').value[0]['type'])
      });


      
      
      
  </script>
  <?php
  if(isset($_GET['save'])){
    $conn= new PDO("mysql:host=localhost;dbname=form-builder","root","root");
    $req = "INSERT INTO form(name,json) value('".$_GET['name']."','".$_GET['tex']."')";
    $formTable = "CREATE TABLE ".$_GET['name']."(id int PRIMARY KEY AUTO_INCREMENT "; 
    $arr = explode(',',$_GET['tab']);
    foreach ($arr as $key => $value) {
      $formTable .= ", $value varchar(100) ";
    }
    $formTable .= ")";
    
   

    if ($conn->query($req)) {
      if ($conn->query($formTable)) {
        $ins = "INSERT INTO ".$_GET['name']." VALUES()";
        if ($conn->query($ins)){
          echo "<div id='alert'><div class='alert alert-success' >insertion success</div></div>";
          header("refresh: 1; url = http://localhost:8888/A--/index.php");
        }else{
          echo "<div id='alert'><div class='alert alert-danger' >erreur d'insertion de ".$_GET['name']."</div></div>";
        }
      }else{
        echo "<div id='alert'><div class='alert alert-danger' >erreur d'insertion de formTable</div></div>";
      }
      
    }else{
      echo "<div id='alert'><div class='alert alert-danger' >erreur d'insertion</div></div>";
    }
  }
  

?>
</body>
</html>

<!-- 
<script src="jquery-3.6.0.min.js"></script>
<script src="jquery-ui.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
  <script src="https://formbuilder.online/assets/js/form-builder.min.js"></script>
<div class="build-wrap"></div>
<script>
jQuery($ => {
  $('.build-wrap').formBuilder()
})
</script>

<script src="form-builder.js"></script> -->


{% extends 'main.html' %}
{% block content %}
{% load static %}
    <style>
      body {
        background: lightgrey;
        font-family: sans-serif;
      }

      #view{
        width: 600px;
        height: 200px;
        background-color: white;
        position: absolute;
        left: 300px;
        top: 100px;
        z-index: 1;
      }


      .form-rendered #build-wrap {
        display: none;
      }

      .render-wrap {
        display: none;
        background-color: wheat;
      }

      .form-rendered .render-wrap {
        display: block;
      }

      #edit-form {
        display: none;
        float: right;
      }

      .form-rendered #edit-form {
        display: block;
      }


    </style>

<div id="view">
    <input class="btn-danger" type="button" id="close" value="X">
    <div class="render-wrap"></div>
  </div>


  <form id="form" action="">

    <div id="fb-editor"></div>

    <div id="valid">
      <input type="text" name="name" placeholder="Form Name">
      <input type="submit" class="btn-success" id="save" name="save" value="Valid">
    </div>

    <textarea hidden name="tab" id="tab" cols="30" rows="10"></textarea>
    <textarea hidden name="tex" id="tex" cols="30" rows="10"></textarea>
  </form>



<script src="{% static 'js/jquery-3.6.0.min.js' %}"></script>
<script src="{% static 'js/jquery-ui.js' %}"></script>
<script src="{% static 'js/form-builder.min.js' %}"></script>

  <script src="{% static 'js/form-render.min.js' %}"></script>


  <script>
document.getElementById('view').style.visibility="hidden";
      jQuery(function ($) {

          var fbTemplate = document.getElementById("fb-editor");
          document.getElementById('valid').style.visibility="hidden";



          var options = {
              onSave: function (evt, formData) {
                console.log("formbuilder saved");
                toggleEdit(false);
                $(".render-wrap").formRender({ formData });
                document.getElementById('tex').value = formData
                document.getElementById('valid').style.visibility="visible";
                document.getElementById('view').style.visibility="visible";
                document.getElementById('form').style.opacity=0.2

                const obj = JSON.parse(formData);
                var tab = [];
                obj.forEach(element => {
                  if (element.type != 'header') {
                    tab.push(element.name);
                  }


                });
                document.getElementById('tab').value = tab;


              },
              onClearAll: function(formData) {
                document.getElementById('valid').style.visibility="hidden";
                toggleEdit(true);
              }
          };



          $(fbTemplate).formBuilder(options);



      });
      function toggleEdit(editing) {
        document.body.classList.toggle("form-rendered", !editing);
      }

      document.getElementById('close').addEventListener('click', function() {
            document.getElementById('view').style.visibility="hidden";
            document.getElementById('form').style.opacity=1

      });



  </script>



{% endblock content%}

