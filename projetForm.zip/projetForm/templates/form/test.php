<!DOCTYPE html>
<html>
<head>
    <title>view</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<style>
    .code{
        margin-left: 400px;
        margin-top: 50px;
        width: 500px;
        height: auto;
        
    }
</style>
<body>
    <textarea hidden name="tex" id="tex" cols="30" rows="10"><?php if(isset($_GET['tex'])){echo $_GET['tex'];}else{echo $_GET['Utex'];}?></textarea>
    <form action="">
        
        


        <div class="code">
         <code id="markup"></code>
         <?php
         if(isset($_GET['Utex'])){
            echo "<input type='hidden' name='formName' value='".$_GET['formName']."'>";
            echo "<input type='submit' class='btn btn-success' name='valid' value='valid'>";
         }
         ?>
         
        </div>
        


    </form>
  <script src="jquery-3.6.0.min.js"></script>
  <script src="jquery-ui.js"></script>
  <script src="form-builder.min.js"></script>
  <script src="form-render.min.js"></script>
  <script>
    


      jQuery(function($) {
        const code = document.getElementById("markup");
        const formData = document.getElementById("tex").value;
        const addLineBreaks = html => html.replace(new RegExp("><", "g"), ">\n<");

        // Grab markup and escape it
        const $markup = $("<div/>");
        $markup.formRender({ formData });

        // set < code > innerText with escaped markup
        code.innerHTML = addLineBreaks($markup.formRender("html"));


        //hljs.highlightBlock(code);
        
      });
    
    
    

  </script>

<?php
    if(isset($_GET['valid'])){
        $conn= new PDO("mysql:host=localhost;dbname=form-builder","root","root");
        $req1 = "SELECT * FROM ".$_GET['formName'];

        $data1 = $conn->query($req1);
                        
        $res1 = $data1->fetch(PDO::FETCH_ASSOC);
        
        $head = [];
        $c=-1;
        foreach ($res1 as $key => $value) {
            if ($key != 'id') {
                array_push($head,$key);
            }
            $c++;
        }

        $val = [];
        foreach ($_GET as $key => $value) {
            if (!in_array($key,['formName','valid'])) {
                array_push($val,$value);
            }
                
        }

        //var_dump($head);

        $insert = "INSERT INTO ".$_GET['formName']."(";
       
        foreach ($head as $key => $value) {
            if ($key==0) {
                $insert .= "$value";
            }else{
                $insert .= ",$value";
            }
            
        }
        $insert .= ") VALUES (";
        //var_dump($val);

        foreach ($val as $key => $value) {
            if ($key==0) {
                $insert .= "'$value'";
            }else{
                $insert .= ",'$value'";
            }
        }
        $insert .= ")";
        var_dump($insert);

        if ($conn->query($insert)) {
            echo "<div id='alert'><div class='alert alert-success' > ' ".$_GET['formName']." ' insertion success</div></div>";
            header("refresh: 1; url = http://localhost:8888/A--/user.php");
          }else{
            echo "<div id='alert'><div class='alert alert-danger' >erreur d'insertion</div></div>";
          }
    }
        
        

        ?>


